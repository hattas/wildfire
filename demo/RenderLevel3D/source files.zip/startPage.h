#pragma once
#include "lib/color.h"

void loading(void);
void homeScreen(void);
void howToPage(void);
void aboutPage(void);
void startPageIdle(void);
int startPageClick(int button, int x, int y);
void setcolor3ub(Color color);